/* =========================================================
   CAKES & BREAD - APP LOGIC
   ========================================================= */

(function () {
  "use strict";

  /* ---------------- STATE ---------------- */
  let cart = loadCart(); // { productId, sizeIndex, qty, note }[]
  let activeCategory = "all";
  let currentProduct = null;
  let selectedSizeIndex = 0;
  let selectedQty = 1;
  let deliveryLocation = localStorage.getItem("cb_location") || "";
  let deliveryCoords = JSON.parse(localStorage.getItem("cb_coords") || "null"); // {lat, lng}
  let selectedTip = 0;
  let selectedPayMethod = "Cash on Delivery";
  let selectedWaNumber = WHATSAPP_NUMBERS.primary;
  let floatCartDismissed = false;

  /* ---------------- SPLASH ---------------- */
  // The splash screen's "go away" was CSS-only: an animation ending in
  // opacity:0/visibility:hidden/pointer-events:none, filled forward so it
  // stays in that end state after playing. That's normally enough, but it
  // depends on the browser actually committing that end state - and this
  // is a position:fixed, inset:0 box sitting on top of literally
  // everything, so if that commit doesn't happen (some in-app/WebView
  // browsers are known to delay repainting an animation-filled end state
  // until something forces layout; @media (prefers-reduced-motion:
  // reduce) - on by default on plenty of real devices - also collapses
  // this animation's *duration* to near-zero while leaving its *delay*
  // alone, which is exactly the kind of edge case those repaint bugs show
  // up under) the splash can be invisible yet still fully intercepting
  // every tap, scroll and click app-wide. That matches "scroll works
  // during the loading dots, then stops the instant loading finishes"
  // precisely - the splash "finishing" is the moment this can go wrong.
  //
  // Fixed by not trusting a CSS end-state alone for something this
  // consequential: once the splash has had time to play, JS removes it
  // from the DOM outright (not just hides it), on a plain timer that
  // doesn't depend on the animation itself firing or completing at all.
  // An element that no longer exists can't block input no matter what any
  // browser does with animation fill-modes. 2500ms comfortably clears the
  // CSS animation's own 2.2s delay + 0.6s duration in every case,
  // including the reduced-motion one where the visual finishes almost
  // instantly but the delay is untouched.
  const splash = document.getElementById("splash");
  if (splash) {
    setTimeout(() => splash.remove(), 2500);
  }

  /* ---------------- UTIL ---------------- */
  // NOTE: this app previously locked body scroll (position:fixed trick)
  // whenever a bottom sheet was open, so the page behind it couldn't
  // scroll. That mechanism kept causing the page to get stuck unscrollable
  // in the field, so it has been removed entirely. Sheets now simply sit
  // on top of the page (they're position:fixed with a backdrop and their
  // own internal scroll), and the page underneath is just... a normal
  // page. There is no lock state to leave stuck, so this class of bug
  // can't happen anymore.

  function formatMoney(n) {
    return "₹" + Math.round(n).toLocaleString("en-IN");
  }
  function loadCart() {
    try {
      return JSON.parse(localStorage.getItem("cb_cart")) || [];
    } catch (e) {
      return [];
    }
  }
  function saveCart() {
    localStorage.setItem("cb_cart", JSON.stringify(cart));
  }
  function showToast(msg) {
    const toast = document.getElementById("toast");
    toast.textContent = msg;
    toast.classList.add("show");
    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => toast.classList.remove("show"), 1800);
  }
  function getProduct(id) {
    return PRODUCTS.find((p) => p.id === id);
  }
  function cartLineKey(productId, sizeIndex) {
    return productId + "::" + sizeIndex;
  }
  function cartQtyTotal() {
    return cart.reduce((sum, l) => sum + l.qty, 0);
  }
  function cartItemTotal() {
    return cart.reduce((sum, l) => {
      const p = getProduct(l.productId);
      if (!p) return sum;
      const price = p.sizes[l.sizeIndex] ? p.sizes[l.sizeIndex].price : p.basePrice;
      return sum + price * l.qty;
    }, 0);
  }
  // Total quantity across every size-line of one product (used to decide
  // whether the card shows "ADD" or the inline qty stepper).
  function productCartQty(productId) {
    return cart.filter((l) => l.productId === productId).reduce((sum, l) => sum + l.qty, 0);
  }
  // For single-size products the stepper can safely adjust cart quantity
  // in place. For multi-size products we still rely on the sheet to pick a
  // size the first time, then step the size the customer actually chose.
  function defaultSizeIndexFor(productId) {
    const line = cart.find((l) => l.productId === productId);
    return line ? line.sizeIndex : 0;
  }
  function adjustCartQty(productId, sizeIndex, delta) {
    const key = cartLineKey(productId, sizeIndex);
    const idx = cart.findIndex((l) => cartLineKey(l.productId, l.sizeIndex) === key);
    if (idx === -1) {
      if (delta > 0) cart.push({ productId, sizeIndex, qty: delta });
    } else {
      cart[idx].qty += delta;
      if (cart[idx].qty <= 0) cart.splice(idx, 1); // minus at 1 removes the item entirely
    }
    saveCart();
    updateCartBadges();
  }

  /* ---------------- NAVIGATION ---------------- */
  // Body scroll is NEVER locked, full stop - there is no lock function,
  // no counter, no position:fixed-on-body trick anywhere in this file.
  // That mechanism (whatever shape it takes - boolean, ref-count, with or
  // without "safety net" resets on visibilitychange/pageshow) is exactly
  // what was causing the page to go permanently unscrollable in the field:
  // any close path that didn't run (hardware back, a gesture, a cut-off
  // transition, a backgrounded tab) left body pinned with position:fixed
  // and nothing left to unpin it, and even the "safety nets" themselves
  // could snap scroll position around on every tab refocus. Removing the
  // mechanism removes the entire bug class instead of chasing another edge
  // case in it.
  //
  // Sheets (product detail, delivery location, contact, custom cake) don't
  // need body locked to work: each is position:fixed with its own
  // `overflow-y: auto` (see .sheet in styles.css) so it scrolls
  // independently, and its backdrop covers the full screen while open, so
  // the page behind it isn't visible to scroll anyway. Closed sheets and
  // backdrops are `pointer-events: none` unconditionally (not gated on a
  // transition finishing), so they can never block input either. That's
  // the only state that matters - there's nothing for JS to track.
  //
  // Any sheet left visually open by an interrupted transition, a
  // backgrounded tab, or a bfcache restore is still swept closed below by
  // forceCloseAllOverlays() - it just no longer touches scroll at all.
  function forceCloseAllOverlays() {
    document.querySelectorAll(".sheet.open").forEach((s) => s.classList.remove("open"));
    document.querySelectorAll(".sheet-backdrop.open").forEach((b) => b.classList.remove("open"));
  }

  function showScreen(id) {
    // Belt-and-braces: any sheet still visually open when the user changes
    // screens (e.g. via a hardware/gesture back action) is force-closed.
    forceCloseAllOverlays();

    document.querySelectorAll(".screen").forEach((s) => s.classList.remove("active"));
    const target = document.getElementById(id);
    if (target) target.classList.add("active");
    document.querySelectorAll(".nav-btn").forEach((b) => {
      b.classList.toggle("active", b.dataset.screen === id);
    });
    window.scrollTo(0, 0);

    // Bottom nav & floating cart bar are hidden during checkout/success so nothing
    // can ever sit on top of (or be covered by) the nav; a full-focus flow instead.
    const focusFlow = id === "screen-summary" || id === "screen-success";
    document.getElementById("bottomNav").classList.toggle("force-hidden", focusFlow);

    updateFloatCartVisibility();
    // the cart screen's sticky checkout bar should only exist while cart screen is active
    const checkoutBar = document.getElementById("cartCheckoutBar");
    if (checkoutBar && id !== "screen-cart") checkoutBar.remove();
  }

  // Extra safety net beyond showScreen(): a CSS transition/animation can get
  // cut off mid-flight the moment a tab is backgrounded, and a page restored
  // from the browser's back/forward cache (bfcache) reappears in whatever
  // visual state it was frozen in rather than re-running normal load logic.
  // Both are real-world moments a sheet/backdrop/lock's "closed" state could
  // fail to actually apply. Re-running the same force-close whenever the tab
  // becomes visible again, or whenever the page is (re)shown at all, means
  // the user is never the one who has to discover a stuck overlay or a
  // stuck lock - it's already cleared by the time they look at the screen
  // again.
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") forceCloseAllOverlays();
  });
  window.addEventListener("pageshow", () => {
    forceCloseAllOverlays();
  });

  document.querySelectorAll(".nav-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const screen = btn.dataset.screen;
      if (screen === "screen-menu") renderMenuScreen("all");
      if (screen === "screen-cart") renderCartScreen();
      showScreen(screen);
    });
  });

  document.querySelectorAll("[data-back]").forEach((btn) => {
    btn.addEventListener("click", () => showScreen(btn.dataset.back));
  });

  document.getElementById("heroShopBtn").addEventListener("click", () => {
    renderMenuScreen("all");
    showScreen("screen-menu");
  });

  document.getElementById("backHomeBtn").addEventListener("click", () => {
    showScreen("screen-home");
  });

  /* ---------------- HOME: CATEGORIES ---------------- */
  function renderCategories() {
    const wrap = document.getElementById("categoryScroll");
    wrap.innerHTML = CATEGORIES.map(
      (c) => `
      <button class="cat-item" data-cat="${c.id}">
        <div class="cat-circle"><i class="${c.icon}"></i></div>
        <span>${c.name}</span>
      </button>`
    ).join("");
    wrap.querySelectorAll(".cat-item").forEach((el) => {
      el.addEventListener("click", () => {
        renderMenuScreen(el.dataset.cat);
        showScreen("screen-menu");
      });
    });
  }

  /* ---------------- HOME: OFFERS STRIP ---------------- */
  function renderOffers() {
    const wrap = document.getElementById("offersScroll");
    if (!wrap || typeof OFFERS === "undefined") return;
    wrap.innerHTML = OFFERS.map(
      (o) => `
      <div class="offer-card">
        <div class="offer-icon"><i class="${o.icon}"></i></div>
        <div class="offer-body">
          <strong>${o.title}</strong>
          <span>${o.sub}</span>
          <span class="offer-tag">${o.tag}</span>
        </div>
      </div>`
    ).join("");
  }

  /* ---------------- HOME: REVIEW HIGHLIGHTS ---------------- */
  function renderReviewHighlights() {
    const wrap = document.getElementById("reviewHighlights");
    if (!wrap || typeof HIGHLIGHTS === "undefined") return;
    wrap.innerHTML = HIGHLIGHTS.map(
      (h) => `<div class="review-highlight"><i class="${h.icon}"></i><span>${h.text}</span></div>`
    ).join("");
  }

  /* ---------------- HOME: BESTSELLERS GRID ---------------- */
  function renderProductGrid() {
    const wrap = document.getElementById("productGrid");
    const bestsellers = PRODUCTS.filter((p) => p.badge === "Bestseller" || p.rating >= 4.7).slice(0, 6);
    document.getElementById("menuCount").textContent = bestsellers.length + " items";
    wrap.innerHTML = bestsellers.map(productCardHtml).join("");
    attachProductCardEvents(wrap);
  }

  // Shared "ADD" button / inline quantity stepper for both grid cards and list
  // rows. Once a line for this product exists, plus/minus adjust it directly
  // in place, no sheet needed; minus at qty 1 removes the item from the cart.
  function addControlHtml(p) {
    const qty = productCartQty(p.id);
    if (qty <= 0) {
      return `<button class="add-btn" data-open="${p.id}">ADD</button>`;
    }
    return `
      <div class="qty-stepper qty-stepper-sm" data-stepper="${p.id}">
        <button data-step="-1" aria-label="Remove one"><i class="fa-solid fa-minus"></i></button>
        <span>${qty}</span>
        <button data-step="1" aria-label="Add one"><i class="fa-solid fa-plus"></i></button>
      </div>`;
  }

  function productCardHtml(p) {
    const qty = productCartQty(p.id);
    return `
    <div class="product-card" data-id="${p.id}">
      <div class="product-img">
        ${p.badge ? `<span class="product-badge">${p.badge}</span>` : ""}
        <div class="veg-dot"><span></span></div>
        <i class="${p.icon}"></i>
      </div>
      <div class="product-info">
        <div class="product-name">${p.name}</div>
        <div class="product-desc">${p.desc}</div>
        <div class="product-rating"><i class="fa-solid fa-star"></i> ${p.rating}</div>
        <div class="product-bottom${qty > 0 ? " has-stepper" : ""}">
          <div class="product-price">${formatMoney(p.basePrice)} <small>onwards</small></div>
          ${addControlHtml(p)}
        </div>
      </div>
    </div>`;
  }

  function productRowHtml(p) {
    return `
    <div class="product-row" data-id="${p.id}">
      <div class="product-row-img"><i class="${p.icon}"></i>${p.badge ? `<span class="product-badge" style="position:absolute;top:6px;left:6px;">${p.badge}</span>` : ""}</div>
      <div class="product-row-body">
        <div class="product-row-top">
          <div class="product-row-name">${p.name}</div>
        </div>
        <div class="product-row-desc">${p.desc}</div>
        <div class="product-row-bottom">
          <div class="product-price">${formatMoney(p.basePrice)} <small>onwards</small></div>
          ${addControlHtml(p)}
        </div>
      </div>
    </div>`;
  }

  // Re-render every visible product listing in place (grid + menu list +
  // search results) without losing scroll position - used after any cart
  // quantity change so all steppers everywhere stay in sync.
  function refreshVisibleProductControls() {
    document.querySelectorAll("[data-stepper], [data-open]").forEach((el) => {
      const id = el.dataset.stepper || el.dataset.open;
      const host = el.closest(".product-card, .product-row");
      if (!host) return;
      const bottom = host.querySelector(".product-bottom, .product-row-bottom");
      if (!bottom) return;
      const p = getProduct(id);
      if (!p) return;
      const priceEl = bottom.querySelector(".product-price");
      bottom.innerHTML = "";
      if (priceEl) bottom.appendChild(priceEl);
      bottom.insertAdjacentHTML("beforeend", addControlHtml(p));
      bottom.classList.toggle("has-stepper", productCartQty(id) > 0);
    });
    rewireStepperButtons(document);
  }

  function rewireStepperButtons(container) {
    container.querySelectorAll("[data-stepper]").forEach((el) => {
      if (el.dataset.wired) return;
      el.dataset.wired = "1";
      const productId = el.dataset.stepper;
      el.querySelectorAll("[data-step]").forEach((btn) => {
        btn.addEventListener("click", (e) => {
          e.stopPropagation();
          const delta = parseInt(btn.dataset.step, 10);
          const p = getProduct(productId);
          if (!p) return;
          const sizeIndex = defaultSizeIndexFor(productId);
          // multi-size products: the first + press with no existing line
          // still needs a size choice, so open the sheet instead of guessing
          if (delta > 0 && p.sizes.length > 1 && productCartQty(productId) === 0) {
            openProductSheet(productId);
            return;
          }
          adjustCartQty(productId, sizeIndex, delta);
          floatCartDismissed = false;
          refreshVisibleProductControls();
        });
      });
    });
  }

  function attachProductCardEvents(container) {
    container.querySelectorAll("[data-open]").forEach((el) => {
      el.addEventListener("click", (e) => {
        e.stopPropagation();
        openProductSheet(el.dataset.open);
      });
    });
    rewireStepperButtons(container);
    container.querySelectorAll(".product-card, .product-row").forEach((el) => {
      el.addEventListener("click", () => openProductSheet(el.dataset.id));
    });
  }

  /* ---------------- MENU SCREEN ---------------- */
  function renderMenuScreen(catId) {
    activeCategory = catId;
    const titleMap = { all: "All Items" };
    document.getElementById("menuScreenTitle").textContent =
      catId === "all" ? "All Items" : CATEGORIES.find((c) => c.id === catId)?.name || "Menu";

    const chipRow = document.getElementById("chipRow");
    chipRow.innerHTML =
      `<button class="chip ${catId === "all" ? "active" : ""}" data-chip="all">All</button>` +
      CATEGORIES.map((c) => `<button class="chip ${catId === c.id ? "active" : ""}" data-chip="${c.id}">${c.name}</button>`).join("");
    chipRow.querySelectorAll(".chip").forEach((chip) => {
      chip.addEventListener("click", () => renderMenuScreen(chip.dataset.chip));
    });

    const list = document.getElementById("productList");
    const items = catId === "all" ? PRODUCTS : PRODUCTS.filter((p) => p.category === catId);
    list.innerHTML = items.map(productRowHtml).join("");
    attachProductCardEvents(list);
  }

  /* ---------------- SEARCH ---------------- */
  document.getElementById("openSearch").addEventListener("click", openSearchScreen);
  document.getElementById("openSearch2").addEventListener("click", openSearchScreen);
  function openSearchScreen() {
    showScreen("screen-search");
    document.getElementById("searchResults").innerHTML = "";
    document.getElementById("searchEmpty").classList.add("hidden");
    setTimeout(() => document.getElementById("searchInput").focus(), 200);
  }
  document.getElementById("searchInput").addEventListener("input", (e) => {
    const q = e.target.value.trim().toLowerCase();
    const resultsWrap = document.getElementById("searchResults");
    const emptyWrap = document.getElementById("searchEmpty");
    if (!q) {
      resultsWrap.innerHTML = "";
      emptyWrap.classList.add("hidden");
      return;
    }
    const results = PRODUCTS.filter(
      (p) => p.name.toLowerCase().includes(q) || p.desc.toLowerCase().includes(q) || p.category.includes(q)
    );
    if (results.length === 0) {
      resultsWrap.innerHTML = "";
      emptyWrap.classList.remove("hidden");
    } else {
      emptyWrap.classList.add("hidden");
      resultsWrap.innerHTML = results.map(productRowHtml).join("");
      attachProductCardEvents(resultsWrap);
    }
  });
  document.getElementById("clearSearch").addEventListener("click", () => {
    const input = document.getElementById("searchInput");
    input.value = "";
    input.dispatchEvent(new Event("input"));
    input.focus();
  });

  /* ---------------- PRODUCT SHEET ---------------- */
  const productBackdrop = document.getElementById("productBackdrop");
  const productSheet = document.getElementById("productSheet");

  function openProductSheet(productId) {
    const p = getProduct(productId);
    if (!p) return;
    currentProduct = p;
    selectedSizeIndex = 0;
    selectedQty = 1;
    renderProductSheetBody();
    productBackdrop.classList.add("open");
    productSheet.classList.add("open");
  }

  function closeProductSheet() {
    productBackdrop.classList.remove("open");
    productSheet.classList.remove("open");
  }
  document.getElementById("closeProductSheet").addEventListener("click", closeProductSheet);
  productBackdrop.addEventListener("click", closeProductSheet);

  function renderProductSheetBody() {
    const p = currentProduct;
    const size = p.sizes[selectedSizeIndex];
    const total = size.price * selectedQty;

    const body = document.getElementById("productSheetBody");
    body.innerHTML = `
      <div class="product-sheet-img"><i class="${p.icon}"></i></div>
      <h2>${p.name}</h2>
      <div class="product-rating" style="margin-bottom:10px;"><i class="fa-solid fa-star"></i> ${p.rating} rating</div>
      <p class="product-sheet-desc">${p.desc}</p>

      <div class="psheet-block">
        <label>Select Size / Weight</label>
        <div class="option-row" id="sizeOptions">
          ${p.sizes
            .map(
              (s, i) => `
            <button class="option-chip ${i === selectedSizeIndex ? "active" : ""}" data-size="${i}">
              ${s.label}<small>${formatMoney(s.price)}</small>
            </button>`
            )
            .join("")}
        </div>
      </div>

      <div class="psheet-block">
        <label>Quantity</label>
        <div class="qty-stepper">
          <button id="qtyMinus"><i class="fa-solid fa-minus"></i></button>
          <span id="qtyValue">${selectedQty}</span>
          <button id="qtyPlus"><i class="fa-solid fa-plus"></i></button>
        </div>
      </div>

      <div class="psheet-footer">
        <div class="psheet-price">
          <strong id="sheetTotalPrice">${formatMoney(total)}</strong>
          <span>Total for ${selectedQty} item${selectedQty > 1 ? "s" : ""}</span>
        </div>
        <button class="btn-primary" id="addToCartBtn"><i class="fa-solid fa-bag-shopping"></i> Add to Cart</button>
      </div>
    `;

    body.querySelectorAll("[data-size]").forEach((el) => {
      el.addEventListener("click", () => {
        selectedSizeIndex = parseInt(el.dataset.size, 10);
        renderProductSheetBody();
      });
    });
    document.getElementById("qtyMinus").addEventListener("click", () => {
      if (selectedQty > 1) selectedQty--;
      renderProductSheetBody();
    });
    document.getElementById("qtyPlus").addEventListener("click", () => {
      if (selectedQty < 20) selectedQty++;
      renderProductSheetBody();
    });
    document.getElementById("addToCartBtn").addEventListener("click", addCurrentToCart);
  }

  function addCurrentToCart() {
    const p = currentProduct;
    const key = cartLineKey(p.id, selectedSizeIndex);
    const existing = cart.find((l) => cartLineKey(l.productId, l.sizeIndex) === key);
    if (existing) {
      existing.qty += selectedQty;
    } else {
      cart.push({ productId: p.id, sizeIndex: selectedSizeIndex, qty: selectedQty });
    }
    saveCart();
    floatCartDismissed = false; // re-show the float bar since the cart just changed
    updateCartBadges();
    showToast(p.name + " added to cart");
    closeProductSheet();
    // refresh visible product lists to show "Added" state
    renderProductGrid();
    if (document.getElementById("screen-menu").classList.contains("active")) renderMenuScreen(activeCategory);
  }

  /* ---------------- CART BADGES / FLOAT BAR ---------------- */
  function updateCartBadges() {
    const count = cartQtyTotal();
    const badge = document.getElementById("navCartBadge");
    if (count > 0) {
      badge.textContent = count;
      badge.classList.remove("hidden");
      badge.classList.remove("bump");
      // restart the bump animation every time the count changes
      void badge.offsetWidth;
      badge.classList.add("bump");
    } else {
      badge.classList.add("hidden");
    }
    updateFloatCartVisibility();
  }

  function updateFloatCartVisibility() {
    const floatCart = document.getElementById("floatCart");
    const count = cartQtyTotal();
    const onCartOrSummary =
      document.getElementById("screen-cart").classList.contains("active") ||
      document.getElementById("screen-summary").classList.contains("active") ||
      document.getElementById("screen-success").classList.contains("active");
    if (count > 0 && !onCartOrSummary && !floatCartDismissed) {
      floatCart.classList.remove("hidden");
      document.getElementById("floatCartCount").textContent = count + (count === 1 ? " item" : " items");
      document.getElementById("floatCartTotal").textContent = formatMoney(cartItemTotal());
    } else {
      floatCart.classList.add("hidden");
    }
  }
  document.getElementById("floatCartBtn").addEventListener("click", () => {
    renderCartScreen();
    showScreen("screen-cart");
  });

  // Cross/close button on the floating cart bar: dismiss it for this session
  // without touching the cart contents (the nav "Cart" tab + badge still work).
  document.getElementById("floatCartClose").addEventListener("click", (e) => {
    e.stopPropagation();
    floatCartDismissed = true;
    document.getElementById("floatCart").classList.add("hidden");
  });

  /* ---------------- CART SCREEN ---------------- */
  function renderCartScreen() {
    const emptyState = document.getElementById("cartEmptyState");
    const content = document.getElementById("cartContent");

    // remove old checkout bar if present
    const oldBar = document.getElementById("cartCheckoutBar");
    if (oldBar) oldBar.remove();

    if (cart.length === 0) {
      emptyState.classList.remove("hidden");
      content.classList.add("hidden");
      return;
    }
    emptyState.classList.add("hidden");
    content.classList.remove("hidden");

    const itemsWrap = document.getElementById("cartItems");
    itemsWrap.innerHTML = cart
      .map((line) => {
        const p = getProduct(line.productId);
        if (!p) return "";
        const size = p.sizes[line.sizeIndex];
        const lineTotal = size.price * line.qty;
        return `
        <div class="cart-item" data-key="${cartLineKey(line.productId, line.sizeIndex)}">
          <div class="cart-item-img"><i class="${p.icon}"></i></div>
          <div class="cart-item-body">
            <div class="cart-item-name">${p.name}</div>
            <div class="cart-item-meta">${size.label}</div>
            <div class="cart-item-bottom">
              <div class="cart-item-price">${formatMoney(lineTotal)}</div>
              <div style="display:flex;align-items:center;gap:10px;">
                <div class="mini-stepper">
                  <button data-action="minus"><i class="fa-solid fa-minus"></i></button>
                  <span>${line.qty}</span>
                  <button data-action="plus"><i class="fa-solid fa-plus"></i></button>
                </div>
                <button class="remove-item" data-action="remove"><i class="fa-solid fa-trash"></i></button>
              </div>
            </div>
          </div>
        </div>`;
      })
      .join("");

    itemsWrap.querySelectorAll(".cart-item").forEach((el) => {
      const key = el.dataset.key;
      const line = cart.find((l) => cartLineKey(l.productId, l.sizeIndex) === key);
      el.querySelector('[data-action="plus"]').addEventListener("click", () => {
        line.qty++;
        saveCart();
        renderCartScreen();
        updateCartBadges();
      });
      el.querySelector('[data-action="minus"]').addEventListener("click", () => {
        line.qty--;
        if (line.qty <= 0) cart = cart.filter((l) => l !== line);
        saveCart();
        renderCartScreen();
        updateCartBadges();
      });
      el.querySelector('[data-action="remove"]').addEventListener("click", () => {
        cart = cart.filter((l) => l !== line);
        saveCart();
        renderCartScreen();
        updateCartBadges();
        showToast("Item removed");
      });
    });

    renderBill();
    injectCheckoutBar();
  }

  function renderBill() {
    const itemTotal = cartItemTotal();
    const freeDelivery = itemTotal >= FREE_DELIVERY_ABOVE;
    const deliveryFee = freeDelivery ? 0 : DELIVERY_FEE;

    document.getElementById("billItemTotal").textContent = formatMoney(itemTotal);
    document.getElementById("billDelivery").textContent = freeDelivery ? "FREE" : formatMoney(deliveryFee);

    const tipRow = document.getElementById("billTipRow");
    if (selectedTip > 0) {
      tipRow.style.display = "flex";
      document.getElementById("billTip").textContent = formatMoney(selectedTip);
    } else {
      tipRow.style.display = "none";
    }

    const discountRow = document.getElementById("billDiscountRow");
    if (freeDelivery) {
      discountRow.style.display = "flex";
      document.getElementById("billDiscount").textContent = "-" + formatMoney(DELIVERY_FEE);
    } else {
      discountRow.style.display = "none";
    }

    const grandTotal = itemTotal + deliveryFee + selectedTip;
    document.getElementById("billGrandTotal").textContent = formatMoney(grandTotal);

    const note = document.getElementById("freeDeliveryNote");
    if (!freeDelivery) {
      const remaining = FREE_DELIVERY_ABOVE - itemTotal;
      note.textContent = `Add ${formatMoney(remaining)} more to get FREE delivery`;
    } else {
      note.textContent = "You unlocked FREE delivery on this order";
    }
  }

  function injectCheckoutBar() {
    if (cart.length === 0) return;
    const existing = document.getElementById("cartCheckoutBar");
    if (existing) existing.remove();
    const bar = document.createElement("div");
    bar.className = "cart-checkout-bar";
    bar.id = "cartCheckoutBar";
    bar.innerHTML = `
      <div class="checkout-total">
        <strong id="ccbTotal">${formatMoney(cartItemTotal() + (cartItemTotal() >= FREE_DELIVERY_ABOVE ? 0 : DELIVERY_FEE) + selectedTip)}</strong>
        <span>TOTAL</span>
      </div>
      <button class="btn-checkout" id="proceedToSummary">Proceed to Checkout <i class="fa-solid fa-arrow-right"></i></button>
    `;
    // Appended inside #app (not document.body) so it sits in the same DOM
    // scope as the bottom nav / floating cart bar it visually stacks with -
    // purely structural, since position:fixed already centers it correctly
    // via the shared --app-max-w variable regardless of DOM nesting.
    const appEl = document.getElementById("app") || document.body;
    appEl.appendChild(bar);
    document.getElementById("proceedToSummary").addEventListener("click", () => {
      renderSummaryScreen();
      showScreen("screen-summary");
    });
  }

  // Tip chips
  document.getElementById("tipRow").addEventListener("click", (e) => {
    const chip = e.target.closest(".tip-chip");
    if (!chip) return;
    document.querySelectorAll(".tip-chip").forEach((c) => c.classList.remove("active"));
    chip.classList.add("active");
    selectedTip = parseInt(chip.dataset.tip, 10);
    document.getElementById("tipCustom").value = "";
    renderBill();
    injectCheckoutBar();
  });
  document.getElementById("tipCustom").addEventListener("input", (e) => {
    document.querySelectorAll(".tip-chip").forEach((c) => c.classList.remove("active"));
    selectedTip = parseInt(e.target.value, 10) || 0;
    renderBill();
    injectCheckoutBar();
  });

  // Payment method chips
  document.getElementById("payRow").addEventListener("click", (e) => {
    const chip = e.target.closest(".pay-chip");
    if (!chip) return;
    document.querySelectorAll(".pay-chip").forEach((c) => c.classList.remove("active"));
    chip.classList.add("active");
    selectedPayMethod = chip.dataset.pay;
    renderSummaryScreen();
  });

  document.getElementById("clearCartBtn").addEventListener("click", () => {
    if (cart.length === 0) return;
    if (confirm("Remove all items from your cart?")) {
      cart = [];
      saveCart();
      updateCartBadges();
      renderCartScreen();
      showToast("Cart cleared");
    }
  });

  /* ---------------- SUMMARY SCREEN ---------------- */
  function renderSummaryScreen() {
    const itemTotal = cartItemTotal();
    const freeDelivery = itemTotal >= FREE_DELIVERY_ABOVE;
    const deliveryFee = freeDelivery ? 0 : DELIVERY_FEE;
    const codFee = codDistanceFee();
    const grandTotal = itemTotal + deliveryFee + codFee + selectedTip;

    const itemsWrap = document.getElementById("summaryItems");
    itemsWrap.innerHTML = cart
      .map((line) => {
        const p = getProduct(line.productId);
        const size = p.sizes[line.sizeIndex];
        return `<div class="summary-item-row">
          <span class="si-name">${p.name} x${line.qty}<span class="si-meta">${size.label}</span></span>
          <span>${formatMoney(size.price * line.qty)}</span>
        </div>`;
      })
      .join("");

    document.getElementById("sumItemTotal").textContent = formatMoney(itemTotal);
    document.getElementById("sumDelivery").textContent = freeDelivery ? "FREE" : formatMoney(deliveryFee);

    const codRow = document.getElementById("sumCodRow");
    if (codFee > 0) {
      codRow.style.display = "flex";
      const km = codDistanceKmRounded();
      document.getElementById("sumCodFee").textContent = formatMoney(codFee) + ` (${km.toFixed(1)} km)`;
    } else {
      codRow.style.display = "none";
    }

    const tipRow = document.getElementById("sumTipRow");
    if (selectedTip > 0) {
      tipRow.style.display = "flex";
      document.getElementById("sumTip").textContent = formatMoney(selectedTip);
    } else {
      tipRow.style.display = "none";
    }
    document.getElementById("sumGrandTotal").textContent = formatMoney(grandTotal);
    document.getElementById("sumPayMethod").textContent =
      "Payment method: " + selectedPayMethod +
      (codFee > 0 ? ` (includes distance-based COD charge)` : "");

    // prefill location if saved
    if (deliveryLocation && !document.getElementById("custAddress").value) {
      document.getElementById("custAddress").value = deliveryLocation;
    }
  }

  // WhatsApp number selector on summary
  document.getElementById("waNumSelect").addEventListener("click", (e) => {
    const chip = e.target.closest(".wa-num-chip");
    if (!chip) return;
    document.querySelectorAll(".wa-num-chip").forEach((c) => c.classList.remove("active"));
    chip.classList.add("active");
    selectedWaNumber = chip.dataset.num;
  });

  /* ---------------- SEND ORDER ON WHATSAPP ---------------- */
  document.getElementById("sendWhatsappBtn").addEventListener("click", () => {
    const name = document.getElementById("custName").value.trim();
    const phone = document.getElementById("custPhone").value.trim();
    const address = document.getElementById("custAddress").value.trim();
    const city = document.getElementById("custCity").value.trim();
    const dateTime = document.getElementById("custDateTime").value.trim();
    const note = document.getElementById("orderNote") ? document.getElementById("orderNote").value.trim() : "";

    if (!name || !phone || !address) {
      showToast("Please fill in name, phone and address");
      if (!name) document.getElementById("custName").focus();
      else if (!phone) document.getElementById("custPhone").focus();
      else document.getElementById("custAddress").focus();
      return;
    }
    if (phone.length < 10) {
      showToast("Please enter a valid phone number");
      document.getElementById("custPhone").focus();
      return;
    }

    const itemTotal = cartItemTotal();
    const freeDelivery = itemTotal >= FREE_DELIVERY_ABOVE;
    const deliveryFee = freeDelivery ? 0 : DELIVERY_FEE;
    const codFee = codDistanceFee();
    const grandTotal = itemTotal + deliveryFee + codFee + selectedTip;

    let msg = `Hello Cakes and Breads! I would like to place an order.\n\n`;
    msg += `*Order Details:*\n`;
    cart.forEach((line) => {
      const p = getProduct(line.productId);
      const size = p.sizes[line.sizeIndex];
      msg += `- ${p.name} (${size.label}) x${line.qty} = ${formatMoney(size.price * line.qty)}\n`;
    });
    msg += `\n*Item Total:* ${formatMoney(itemTotal)}`;
    msg += `\n*Delivery Fee:* ${freeDelivery ? "FREE" : formatMoney(deliveryFee)}`;
    if (codFee > 0) {
      msg += `\n*COD Distance Charge:* ${formatMoney(codFee)} (~${codDistanceKmRounded().toFixed(1)} km at ₹${COD_RATE_PER_KM}/km)`;
    }
    if (selectedTip > 0) msg += `\n*Tip for Bakers:* ${formatMoney(selectedTip)}`;
    msg += `\n*Total Amount:* ${formatMoney(grandTotal)}`;
    msg += `\n*Payment Method:* ${selectedPayMethod}`;

    if (note) msg += `\n\n*Note for baker:* ${note}`;

    msg += `\n\n*Customer Details:*`;
    msg += `\nName: ${name}`;
    msg += `\nPhone: ${phone}`;
    msg += `\nAddress: ${address}`;
    if (city) msg += `\nCity/Pincode: ${city}`;
    if (dateTime) msg += `\nPreferred Delivery: ${dateTime}`;
    if (deliveryCoords) {
      msg += `\nLocation Pin: https://www.google.com/maps?q=${deliveryCoords.lat},${deliveryCoords.lng}`;
    }

    msg += `\n\nPlease confirm my order. Thank you!`;

    const url = `https://wa.me/${selectedWaNumber}?text=${encodeURIComponent(msg)}`;
    window.open(url, "_blank");

    // Move to success screen and clear cart
    showScreen("screen-success");
    cart = [];
    saveCart();
    updateCartBadges();
  });

  /* ---------------- LOCATION SHEET ---------------- */
  const locationBackdrop = document.getElementById("locationBackdrop");
  const locationSheet = document.getElementById("locationSheet");
  document.getElementById("openLocationSheet").addEventListener("click", () => {
    document.getElementById("locationInput").value = deliveryLocation;
    locationBackdrop.classList.add("open");
    locationSheet.classList.add("open");
  });
  locationBackdrop.addEventListener("click", hideLocationSheet);
  document.getElementById("closeLocationSheet").addEventListener("click", hideLocationSheet);
  function hideLocationSheet() {
    locationBackdrop.classList.remove("open");
    locationSheet.classList.remove("open");
  }
  document.getElementById("saveLocationBtn").addEventListener("click", () => {
    const val = document.getElementById("locationInput").value.trim();
    if (!val) {
      showToast("Please enter your location");
      return;
    }
    deliveryLocation = val;
    localStorage.setItem("cb_location", val);
    document.getElementById("currentLocation").innerHTML = val.length > 22 ? val.slice(0, 22) + "... <i class='fa-solid fa-chevron-down'></i>" : val + ' <i class="fa-solid fa-chevron-down"></i>';
    hideLocationSheet();
    showToast("Location saved");
  });

  /* ---------------- AUTO-DETECT LOCATION (GPS) ---------------- */
  // Uses the browser Geolocation API (needs the user's permission). On success we
  // reverse-geocode the coordinates to a readable address via OpenStreetMap's
  // Nominatim API; if that's unreachable (offline / blocked) we still save the
  // raw coordinates so delivery location + distance from the store is known.
  /* ---------------- COD DISTANCE CHARGE ---------------- */
  const COD_RATE_PER_KM = 20;
  // Great-circle distance in km between the store and the customer's detected
  // coordinates - the standard Haversine formula.
  function distanceKm(lat1, lng1, lat2, lng2) {
    const R = 6371;
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLng = ((lng2 - lng1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }
  // Only charged for Cash on Delivery, and only once we actually know where
  // the customer is (auto-detected or previously saved coordinates).
  function codDistanceFee() {
    if (selectedPayMethod !== "Cash on Delivery") return 0;
    if (!deliveryCoords) return 0;
    const km = distanceKm(STORE_LAT, STORE_LNG, deliveryCoords.lat, deliveryCoords.lng);
    return Math.round(km * COD_RATE_PER_KM);
  }
  function codDistanceKmRounded() {
    if (!deliveryCoords) return 0;
    return distanceKm(STORE_LAT, STORE_LNG, deliveryCoords.lat, deliveryCoords.lng);
  }

  function primaryDeliveryLat() { return deliveryCoords ? deliveryCoords.lat : STORE_LAT; }
  function primaryDeliveryLng() { return deliveryCoords ? deliveryCoords.lng : STORE_LNG; }

  async function reverseGeocode(lat, lng) {
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=16&addressdetails=1`,
        { headers: { Accept: "application/json" } }
      );
      if (!res.ok) throw new Error("geocode failed");
      const data = await res.json();
      if (data && data.display_name) {
        // Trim to a short, readable form: area + city
        const a = data.address || {};
        const parts = [
          a.suburb || a.neighbourhood || a.road,
          a.city || a.town || a.village || a.county,
          a.state,
        ].filter(Boolean);
        return parts.length ? parts.join(", ") : data.display_name;
      }
    } catch (e) {
      /* offline or blocked, fall through to coordinate label */
    }
    return `Near ${lat.toFixed(4)}, ${lng.toFixed(4)}`;
  }

  function applyDetectedLocation(label, lat, lng) {
    deliveryLocation = label;
    deliveryCoords = { lat, lng };
    localStorage.setItem("cb_location", label);
    localStorage.setItem("cb_coords", JSON.stringify(deliveryCoords));
    document.getElementById("currentLocation").innerHTML =
      (label.length > 22 ? label.slice(0, 22) + "..." : label) + ' <i class="fa-solid fa-chevron-down"></i>';
    const input = document.getElementById("locationInput");
    if (input) input.value = label;
    const addrField = document.getElementById("custAddress");
    if (addrField && !addrField.value.trim()) addrField.value = label;
  }

  function runAutoLocate(btn, labelEl, onDone) {
    if (!("geolocation" in navigator)) {
      showToast("Location services aren't supported on this device");
      return;
    }
    btn.classList.add("locating");
    btn.classList.remove("success");
    if (labelEl) labelEl.textContent = "Detecting your location...";

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        const label = await reverseGeocode(latitude, longitude);
        applyDetectedLocation(label, latitude, longitude);
        btn.classList.remove("locating");
        btn.classList.add("success");
        if (labelEl) labelEl.textContent = "Location detected!";
        showToast("Location updated: " + label);
        if (onDone) onDone(label);
        setTimeout(() => {
          btn.classList.remove("success");
          if (labelEl) labelEl.textContent = btn.dataset.defaultLabel || "Auto-detect my location";
        }, 2200);
      },
      (err) => {
        btn.classList.remove("locating");
        if (labelEl) labelEl.textContent = btn.dataset.defaultLabel || "Auto-detect my location";
        if (err.code === err.PERMISSION_DENIED) {
          showToast("Please allow location access to auto-detect");
        } else {
          showToast("Couldn't detect location, try entering it manually");
        }
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
  }

  const autoLocateBtn = document.getElementById("autoLocateBtn");
  const autoLocateLabel = document.getElementById("autoLocateLabel");
  if (autoLocateBtn) {
    autoLocateBtn.dataset.defaultLabel = autoLocateLabel ? autoLocateLabel.textContent : "";
    autoLocateBtn.addEventListener("click", () => runAutoLocate(autoLocateBtn, autoLocateLabel));
  }

  const useMyLocationBtn = document.getElementById("useMyLocationBtn");
  if (useMyLocationBtn) {
    useMyLocationBtn.dataset.defaultLabel = useMyLocationBtn.innerHTML;
    useMyLocationBtn.addEventListener("click", () => {
      runAutoLocate(useMyLocationBtn, null, (label) => {
        document.getElementById("custAddress").value = label;
        useMyLocationBtn.innerHTML = '<i class="fa-solid fa-check"></i> Location applied';
        renderSummaryScreen();
        setTimeout(() => {
          useMyLocationBtn.innerHTML = useMyLocationBtn.dataset.defaultLabel;
        }, 2200);
      });
    });
  }

  /* ---------------- CONTACT SHEET ---------------- */
  const contactBackdrop = document.getElementById("contactBackdrop");
  const contactSheet = document.getElementById("contactSheet");
  document.getElementById("openContact").addEventListener("click", () => {
    contactBackdrop.classList.add("open");
    contactSheet.classList.add("open");
  });
  function hideContactSheet() {
    contactBackdrop.classList.remove("open");
    contactSheet.classList.remove("open");
  }
  contactBackdrop.addEventListener("click", hideContactSheet);
  document.getElementById("closeContactSheet").addEventListener("click", hideContactSheet);

  /* ---------------- PWA INSTALL ---------------- */
  let deferredPrompt = null;
  const installBanner = document.getElementById("installBanner");

  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    deferredPrompt = e;
    if (!sessionStorage.getItem("cb_install_dismissed") && !isStandalone()) {
      setTimeout(() => installBanner.classList.remove("hidden"), 2600);
    }
  });

  function isStandalone() {
    return window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;
  }

  async function triggerInstall() {
    if (!deferredPrompt) {
      showToast("App already installed or not supported on this browser");
      return;
    }
    deferredPrompt.prompt();
    const choice = await deferredPrompt.userChoice;
    if (choice.outcome === "accepted") {
      showToast("Installing Cakes and Breads...");
    }
    deferredPrompt = null;
    installBanner.classList.add("hidden");
  }

  document.getElementById("installBtn").addEventListener("click", triggerInstall);
  document.getElementById("moreInstallBtn").addEventListener("click", triggerInstall);

  /* ---------------- CUSTOM CAKE ENQUIRY SHEET ---------------- */
  const customBackdrop = document.getElementById("customBackdrop");
  const customSheet = document.getElementById("customSheet");
  let customOccasion = "Birthday";
  let customPhotoDataUrl = null;
  let customPhotoName = "";

  document.getElementById("moreCustomBtn").addEventListener("click", () => {
    customBackdrop.classList.add("open");
    customSheet.classList.add("open");
  });
  function hideCustomSheet() {
    customBackdrop.classList.remove("open");
    customSheet.classList.remove("open");
  }
  customBackdrop.addEventListener("click", hideCustomSheet);
  document.getElementById("closeCustomSheet").addEventListener("click", hideCustomSheet);

  document.getElementById("customOccasionOptions").addEventListener("click", (e) => {
    const btn = e.target.closest("[data-occasion]");
    if (!btn) return;
    customOccasion = btn.dataset.occasion;
    document.querySelectorAll("#customOccasionOptions .option-chip").forEach((c) => c.classList.remove("active"));
    btn.classList.add("active");
  });

  // Reference photo: shown back to the customer as a preview so they can find
  // and attach the same file in WhatsApp afterwards (wa.me links are text-only
  // and cannot attach media on the customer's behalf).
  document.getElementById("customPhotoInput").addEventListener("change", (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      showToast("Please choose an image file");
      return;
    }
    customPhotoName = file.name;
    const reader = new FileReader();
    reader.onload = () => {
      customPhotoDataUrl = reader.result;
      const preview = document.getElementById("customPhotoPreview");
      preview.src = customPhotoDataUrl;
      preview.classList.remove("hidden");
      document.getElementById("customPhotoText").textContent = "Photo selected - " + file.name;
    };
    reader.readAsDataURL(file);
  });

  document.getElementById("sendCustomEnquiryBtn").addEventListener("click", () => {
    const theme = document.getElementById("customTheme").value.trim();
    const size = document.getElementById("customSize").value.trim();
    const dateVal = document.getElementById("customDate").value;
    const instructions = document.getElementById("customInstructions").value.trim();

    let dateLabel = "";
    if (dateVal) {
      const d = new Date(dateVal);
      if (!isNaN(d)) {
        dateLabel = d.toLocaleString("en-IN", { day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit" });
      }
    }

    let msg = "Hello Cakes and Breads! I'd like to enquire about a custom cake.\n\n";
    msg += "*Occasion:* " + customOccasion + "\n";
    if (theme) msg += "*Theme / design idea:* " + theme + "\n";
    if (size) msg += "*Approx. size / servings:* " + size + "\n";
    if (dateLabel) msg += "*Preferred date & time:* " + dateLabel + "\n";
    if (instructions) msg += "*Special instructions:* " + instructions + "\n";
    if (customPhotoName) {
      msg += "\nI have a reference photo (" + customPhotoName + ") saved and ready - I'll attach it in this chat.";
    }
    msg += "\n\nPlease let me know if this is possible and the price. Thank you!";

    window.open(`https://wa.me/${WHATSAPP_NUMBERS.primary}?text=${encodeURIComponent(msg)}`, "_blank");
    hideCustomSheet();
    showToast("Opening WhatsApp with your enquiry...");
  });
  document.getElementById("dismissInstall").addEventListener("click", () => {
    installBanner.classList.add("hidden");
    sessionStorage.setItem("cb_install_dismissed", "1");
  });

  window.addEventListener("appinstalled", () => {
    installBanner.classList.add("hidden");
    showToast("Cakes and Breads installed successfully!");
  });

  /* ---------------- SERVICE WORKER ---------------- */
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("service-worker.js").catch(() => {});
    });
  }

  /* ---------------- INIT ---------------- */
  function init() {
    renderCategories();
    renderProductGrid();
    renderOffers();
    renderReviewHighlights();
    updateCartBadges();
    if (deliveryLocation) {
      document.getElementById("currentLocation").innerHTML =
        (deliveryLocation.length > 22 ? deliveryLocation.slice(0, 22) + "..." : deliveryLocation) + ' <i class="fa-solid fa-chevron-down"></i>';
    }
    showScreen("screen-home");
  }

  document.addEventListener("DOMContentLoaded", init);
  if (document.readyState !== "loading") init();
})();
